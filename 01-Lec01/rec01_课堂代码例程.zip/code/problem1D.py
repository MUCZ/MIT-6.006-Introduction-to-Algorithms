problemList = [1, 2, 3, 4, 5, 6, 5, 4, 3]
